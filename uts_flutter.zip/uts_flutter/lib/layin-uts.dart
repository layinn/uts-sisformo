import 'dart:io';

void main() {
  var daftarmapelHarga = {
    "1": {"nama": "Ilmu Pengetahuan Alam", "harga": 50000},
    "2": {"nama": "Ilmu Pengetahuan Sosial", "harga":50000},
    "3": {"nama": "Matematika", "harga": 100000},
    "4": {"nama": "Bahasa Indonesia", "harga": 50000},
    "5": {"nama": "Bahasa Inggris", "harga": 75000},
    "6": {"nama": "Bahasa Daerah", "harga": 60000},
  };

  String nama;
  String? nomorMapel;
  var mataPelajaranDipilih = <String>[];
  var totalHarga = 0;

  print("Selamat datang di aplikasi pendaftaran!");
  stdout.write("Masukkan nama Anda: ");
  nama = stdin.readLineSync()!;

  do {
    print("\nDaftar Mata Pelajaran:");
  daftarmapelHarga.forEach((nomor, data) {
    print("Nomor: $nomor, Mata Pelajaran: ${data["nama"]}, Tarif: Rp ${data["harga"]}");
  });

    stdout.write("\nPilih nomor mata pelajaran: ");
    nomorMapel = stdin.readLineSync()!;

  if (daftarmapelHarga.containsKey(nomorMapel)) {
    var mataPelajaran = daftarmapelHarga[nomorMapel]!["nama"];
    var harga = daftarmapelHarga[nomorMapel]!["harga"];
    mataPelajaranDipilih.add("mataPelajaran");
    totalHarga = (harga as int?)!;
    print("Siswa $nama telah mendaftar kursus $mataPelajaran dengan tarif Rp $harga.");
  } else {
    print("Kode paket tidak ditemukan.");

  }

    stdout.write("Apakah Anda ingin memilih mata pelajaran lagi? (y/n): ");
    var jawaban = stdin.readLineSync();

    if (jawaban != 'y') {
      break;
    }
  } while (true);

  print("\nTerima kasih, $nama, telah mendaftar!");
  //print("\nJumlah mata pelajaran yang di beli: ");
  print("Total biaya pendaftaran: $totalHarga");
}

// saya menggunakan replit.com untuk membuat tugas, karna di vscode tidk bisa di run

// things that missed in this project : 
// tidak bisa menghitung total biaya pendaftaran, hanya menampilkan harga beli pelajaran yang terakhir
// tidak bisa menghitung berapa banyak mapel yang di beli